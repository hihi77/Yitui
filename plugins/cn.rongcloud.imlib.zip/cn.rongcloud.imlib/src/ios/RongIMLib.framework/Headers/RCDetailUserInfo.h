//
//  RCDetailUserInfo.h
//  RongIMLib
//
//  Created by litao on 15/8/13.
//  Copyright (c) 2015年 RongCloud. All rights reserved.
//

#import "RCUserInfo.h"

@interface RCDetailUserInfo : RCUserInfo
@property (nonatomic, strong, readonly)NSString *jsonString;
@end
