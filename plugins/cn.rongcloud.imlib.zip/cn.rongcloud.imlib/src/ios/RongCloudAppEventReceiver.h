//
//  RongCloudAppEventReceiver.h
//  CordovaDemo
//
//  Created by litao on 15/11/2.
//
//

#import <Foundation/Foundation.h>

@interface RongCloudAppEventReceiver : NSObject

@end
