//
//  RongCloudConstant.h
//  UZApp
//
//  Created by MiaoGuangfa on 12/23/14.
//  Copyright (c) 2014 APICloud. All rights reserved.
//

#ifndef UZApp_RongCloudConstant_h
#define UZApp_RongCloudConstant_h

//NSString * const  DeviceToken_Notification_To_RongCloudModule = @"const_DeviceToken_Notification_To_RongCloudModule";
#ifndef DeviceToken_Notification_To_RongCloudModule
#define DeviceToken_Notification_To_RongCloudModule @"DeviceToken_Notification_To_RongCloudModule"
#endif

#endif
