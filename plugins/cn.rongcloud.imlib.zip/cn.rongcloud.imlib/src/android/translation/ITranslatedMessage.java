package io.rong.cordova.translation;

/**
 * Created by weiqinxiao on 15/9/16.
 */
public interface ITranslatedMessage {
}
