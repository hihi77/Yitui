package io.rong.cordova.translation;

/**
 * Created by weiqinxiao on 15/9/16.
 */
public class TranslatedQuietHour {
    String startTime;
    int spanMinutes;

    public TranslatedQuietHour(String startTime, int spanMinutes) {
        this.startTime = startTime;
        this.spanMinutes = spanMinutes;
    }
}
