package io.rong.cordova.translation;

/**
 * Created by weiqinxiao on 15/9/15.
 */
public class TranslatedMessageContent {
}
